﻿//{{NO_DEPENDENCIES}}
// Plik dołączany wygenerowany przez program Microsoft Visual C++.
// Używane przez: Projekt_4_Szymon_203618_Maciek_203894.rc

#define IDS_APP_TITLE			103

#define IDR_MAINFRAME			128
#define IDD_PROJEKT4SZYMON203618MACIEK203894_DIALOG	102
#define IDD_ABOUTBOX			103
#define IDM_ABOUT				104
#define IDM_EXIT				105
#define IDI_PROJEKT4SZYMON203618MACIEK203894			107
#define IDI_SMALL				108
#define IDC_PROJEKT4SZYMON203618MACIEK203894			109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif
// Następne wartości domyślne dla nowych obiektów
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
